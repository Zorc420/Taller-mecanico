	function ponerfondos(a){
		switch(a){
			case 0:
				document.body.style = "background-image: url(img/programacion1.jpg)"
				;break;
			case 1:
				document.body.style = "background-image: url(img/turismo.jpg)"
				;break;
			case 2:
				document.body.style = "background-image: url(img/construccion.jpg)"
				;break;
			default:
				document.body.style.background = "white"
				;break;
			}
	}
