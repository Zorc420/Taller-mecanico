<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">Taller Mecanico</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link" href="index.php">Index</a>
      <a class="nav-item nav-link" href="mis_mecanicos.php">Mecanicos</a>
      <a class="nav-item nav-link" href="agregar_trabajo.php">Agregar Trabajo</a>
      <a class="nav-item nav-link" href="controles.php">Control</a>
    </div>
  </div>
</nav>