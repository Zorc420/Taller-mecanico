<head>
	<meta charset="UTF-8">
	<title>Document</title>
    <link rel="stylesheet" href="./css/bootstrap.css">
    <script src="./js/jquery.js"></script>
    <script src="./js/bootstrap.js"></script>
</head>
<style>
	body{
		text-align: center;
		background-image: url("./css/fondo.jpg");
		background-size: cover;
		background-repeat: no-repeat;
		background-attachment: fixed;
	}
</style>