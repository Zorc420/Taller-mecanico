<br><br>
<footer class="" style="display: flex; justify-content: center; align-items: center; background-color: rgba(0,0,0,0.5); position: fixed; bottom: 0; width: 100%; padding:5px 0; text-align: center; color: white; font-size: 14px;" >
	apruebenme

</footer>